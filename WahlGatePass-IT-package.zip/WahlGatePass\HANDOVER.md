# Bàn giao cho IT — Giấy phép ra/vào cổng (Wahl Vietnam)

Hệ thống thay thế biểu mẫu giấy HR-F-GEN-0057-01 bằng quy trình điện tử. PDF xuất ra dùng chính ảnh form gốc rồi điền dữ liệu lên (không làm lại form mới).

## 1. Hệ thống gồm gì

| Thành phần | Công nghệ | Ghi chú |
|---|---|---|
| Giao diện web | HTML/CSS/JS thuần, **không cần build** | 3 trang: `index.html` (nhân viên), `hr.html` (duyệt + quản trị), `security.html` (bảo vệ, chỉ xem, không đăng nhập) |
| Backend | Google Apps Script Web App (thư mục `apps-script/`) | Chạy bằng tài khoản Google của người deploy |
| Cơ sở dữ liệu | Google Sheet (6 sheet, `setup()` tự tạo) | Requests, Users, Sessions, Departments, Config, AuditLog |
| Lưu chữ ký | Thư mục Google Drive (`setup()` tự tạo) | Ảnh chữ ký PNG/JPEG |

Luồng duyệt: Nhân viên gửi → Giám sát → Trưởng bộ phận → HR → Được ra. Bước nào bộ phận không có người thì tự bỏ qua. Không có trường nào bắt buộc khi nhân viên gửi giấy (trường trống chỉ tô đỏ nhắc).

## 2. IT cần chuẩn bị

1. **Tài khoản Google do công ty sở hữu** (khuyến nghị dùng tài khoản dịch vụ/chung của công ty, không dùng tài khoản cá nhân) để sở hữu Google Sheet + Apps Script. Mọi dữ liệu và chữ ký nằm trong tài khoản này.
2. Google Workspace của công ty phải cho phép Web App **"Execute as: Me" + "Who has access: Anyone"** (nhân viên và bảo vệ dùng không cần đăng nhập Google). Nếu chính sách công ty chặn "Anyone", cần xin ngoại lệ hoặc báo lại để đổi thiết kế.
3. Nơi chạy **file tĩnh** (nginx/IIS nội bộ, Netlify, GitHub Pages…). Chỉ cần phục vụ các file trong gói, đường dẫn tương đối nên đặt ở thư mục gốc hay sub-path đều được.
4. Một máy có Node.js 18+ nếu muốn chạy bộ test (không bắt buộc để vận hành).

## 3. Các bước triển khai (chi tiết trong `README.md`)

1. Tạo Google Sheet trống → **Extensions → Apps Script**.
2. Tạo các file `.gs` và dán nội dung từ `apps-script/` (Code, Util, Auth, Users, Requests, Departments, Security, Setup) + thay `appsscript.json`.
3. **Project Settings → Script Properties**: thêm `ADMIN_INITIAL_PASSWORD` (mật khẩu tạm mạnh cho tài khoản `admin`).
4. Chạy hàm `setup()` một lần (cấp quyền khi Google hỏi). Hàm chạy lại nhiều lần vẫn an toàn.
5. **Deploy → New deployment → Web app** (Execute as: Me, Access: Anyone) → copy URL `/exec`.
6. Sửa `assets/js/config.js`: đặt `API_URL` bằng URL vừa copy. *(Gói này đang trỏ vào Web App của bản demo cũ — **bắt buộc đổi** sang URL của IT.)*
7. Đưa các file web lên nơi phục vụ file tĩnh.
8. Đăng nhập `hr.html` bằng `admin` + mật khẩu ở bước 3 → bị bắt đổi mật khẩu ngay.
9. Vào tab **Bộ phận & người duyệt** và **Người dùng** để thêm bộ phận, giám sát, trưởng bộ phận, HR (thêm người có vai trò + bộ phận thì tự được gán làm người duyệt). Mỗi người duyệt đăng nhập, đổi mật khẩu, rồi ký chữ ký số ở tab **Tài khoản**.

> Mỗi lần sửa code `.gs` sau này: **Deploy → Manage deployments → Edit → Version: New version → Deploy** (URL giữ nguyên). Nếu tạo "New deployment" mới thì URL đổi và phải sửa lại `config.js`.

## 4. Bảo mật — IT lưu ý

- **Không có bí mật nào trong gói.** `API_URL` công khai theo thiết kế của Apps Script; bảo vệ nằm ở kiểm tra token / vai trò / bộ phận phía server.
- Mật khẩu chỉ lưu dạng băm (SHA-256 nhiều vòng + salt riêng từng người). Khoá tài khoản 15 phút sau 5 lần sai.
- **Sheet `Users` chỉ chia sẻ cho admin** (chứa băm mật khẩu). Thư mục Drive chữ ký cũng không chia sẻ rộng.
- Mật khẩu tạm do admin cấp bắt người dùng đổi ở lần đăng nhập đầu. Nên dùng mật khẩu tạm riêng từng người hoặc để hệ thống tự tạo, tránh một mật khẩu chung cho nhiều người.
- Trang bảo vệ công khai chỉ hiển thị tên, mã NV, bộ phận, giờ, trạng thái và tên người đã duyệt. Không hiện lý do xin phép hay chữ ký.
- Phiên đăng nhập hết hạn sau 8 giờ (12 giờ cho bảo vệ), trang quản lý tự đăng xuất sau 30 phút không thao tác.
- Mọi hành động quản trị và duyệt đều ghi vào sheet `AuditLog`.

## 5. Kiểm thử

- Chạy thử không cần backend: để `API_URL` trống hoặc giữ nguyên placeholder → site chạy **MOCK MODE** (dữ liệu giả trong trình duyệt, có banner vàng). Tài khoản demo: `admin`, `hr01`, `sup01`, `mgr01`, mật khẩu `Test1234`.
- Test tự động logic backend (giả lập Google Apps Script): `node --test tests/*.test.mjs` (37 test).
- Checklist kiểm thử sau khi deploy: mục "Checklist test sau khi deploy" trong `README.md`.

## 6. Vận hành & giới hạn đã biết

- Sao lưu: đặt lịch tải/copy Google Sheet định kỳ (dữ liệu và lịch sử nằm hoàn toàn trong Sheet + thư mục Drive chữ ký).
- Hạn mức (quota) của Apps Script / Drive do Google quy định áp dụng khi lượng người dùng lớn; chưa được đo thử ở quy mô công ty.
- Trang bảo vệ **chỉ xem**: không ghi giờ ra/vào thực tế (ô giờ thực tế và ô chữ ký bảo vệ trên PDF để trống cho bảo vệ ghi tay). Backend vẫn có `recordOut`/`recordIn` cho tài khoản bảo vệ/HR/admin nếu sau này cần bật lại.
- Giấy bị từ chối không lưu thời điểm từ chối (chỉ lưu người từ chối và lý do).
- Thông báo email chưa được triển khai (cấu hình `EMAIL_NOTIFICATIONS_ENABLED` hiện không có tác dụng).

## 7. Cấu trúc gói

```
index.html, hr.html, security.html   # giao diện
assets/                               # css, js, ảnh form gốc
apps-script/                          # code backend (dán vào Apps Script)
tests/                                # test Node
docs/SPEC.md                          # đặc tả: cấu trúc Sheet, API, quyền, state machine
README.md                             # hướng dẫn cài đặt chi tiết
HANDOVER.md                           # file này
```
